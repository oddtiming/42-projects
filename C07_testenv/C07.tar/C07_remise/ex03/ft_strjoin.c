/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iyahoui- <marvin@42quebec.com>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/28 11:24:14 by iyahoui-          #+#    #+#             */
/*   Updated: 2021/07/28 11:24:15 by iyahoui-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
int		ft_strlen(char *str);
char	*fill_string(int size, char *joined, char **strs, char *sep);

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		total_size;
	int		i;
	char	*joined;

	if (!size)
		return ((char *)malloc(1));
	i = -1;
	total_size = 0;
	while (++i < size)
		total_size += ft_strlen(*(strs + i));
	total_size += (size - 1) * ft_strlen(sep) + 1;
	joined = (char *)malloc(total_size * sizeof(char));
	return (fill_string(total_size, joined, strs, sep));
}

char	*fill_string(int size, char *joined, char **strs, char *sep)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < size - 1)
	{
		if ((*strs)[j] == 0)
		{	
			j = 0;
			while (sep[j] != 0)
			{
				joined[i] = sep[j];
				i++;
				j++;
			}
			strs += 1;
			j = 0;
		}
		joined[i] = (*strs)[j];
		i++;
		j++;
	}
	joined[i] = 0;
	return (joined);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}
