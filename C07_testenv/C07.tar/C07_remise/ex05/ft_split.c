/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iyahoui- <marvin@42quebec.com>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/28 11:24:21 by iyahoui-          #+#    #+#             */
/*   Updated: 2021/07/28 11:24:22 by iyahoui-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	is_set(char c, char *set)
{
	int	i;

	i = -1;
	while (set[++i])
		if (c == set[i])
			return (i);
	return (-1);
}

int	count_strs(char *str, char *set)
{
	int	i;
	int	counter;
	int	is_body;

	i = 0;
	counter = 0;
	is_body = 0;
	while (str[++i])
	{
		if (is_set(str[i], set) == -1 && is_set(str[i - 1], set) >= 0)
			is_body = 1;
		if (is_set(str[i], set) && is_body == 1)
		{
			counter++;
			is_body = 0;
		}
	}
	if (is_set(str[i - 1], set) == -1)
		return (counter - 1);
	return (counter);
}

int	chunk_len(char **str, char *set)
{
	int	str_len;
	int	is_chunk;
	int	i;

	is_chunk = 1;
	i = 0;
	str_len = 0;
	while (is_chunk)
	{
		*str += 1;
		if (is_set((*str)[i], set) == -1 && is_set(((*str)[i - 1]), set) >= 0)
		{
			while (is_set((*str)[i++], set) == -1)
				str_len++;
			is_chunk = 0;
		}
	}
	return (str_len);
}

char	**chunk_cpy(char **str, char *set)
{
	int		i;
	int		is_body;
	int		str_len;
	char	*str_cpy;
	char	**address;

	is_body = 1;
	i = 0;
	str_len = chunk_len(str, set);
	str_cpy = (char *)malloc((str_len + 1) * sizeof(char));
	while (i < str_len)
	{
		str_cpy[i] = **str;
		*str += 1;
		i++;
	}
	str_cpy[i] = 0;
	address = &str_cpy;
	return (address);
}

char	**ft_split(char *str, char *charset)
{
	int		i;
	int		nb_chunks;
	char	**strs;

	i = 0;
	nb_chunks = count_strs(str, charset);
	strs = (char **)malloc(sizeof(*strs) * (nb_chunks + 1));
	while (i < nb_chunks)
	{
		strs[i] = &(**(chunk_cpy(&str, charset)));
		i++;
	}
	strs[i] = &(**(chunk_cpy(&str, charset)));
	return (strs);
}
