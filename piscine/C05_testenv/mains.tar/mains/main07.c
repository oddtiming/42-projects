#include <stdio.h>
int	ft_ten_queens_puzzle(void);

int	main(void)
{
	printf("Total number of possibilities: %d.\n", ft_ten_queens_puzzle());
	return (0);
}
